<?php
//000000000000
 exit();?>
s:5:"basic";