<?php
//000000000000
 exit();?>
a:6:{s:2:"id";i:2;s:9:"role_name";s:7:"FASDFAS";s:13:"role_auth_ids";s:4:"23,6";s:12:"role_auth_ac";s:0:"";s:8:"sendtime";i:1588919463;s:6:"status";i:1;}