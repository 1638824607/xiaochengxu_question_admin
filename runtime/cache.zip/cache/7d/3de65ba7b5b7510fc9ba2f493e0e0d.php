<?php
//000000000000
 exit();?>
a:8:{s:2:"id";i:1;s:10:"model_name";s:20:"[列表]新闻列表";s:12:"model_fields";s:15:"1,3,7,8,9,10,13";s:7:"model_c";s:4:"News";s:7:"model_a";s:5:"Index";s:5:"ispic";i:1;s:8:"disorder";i:0;s:6:"status";i:1;}