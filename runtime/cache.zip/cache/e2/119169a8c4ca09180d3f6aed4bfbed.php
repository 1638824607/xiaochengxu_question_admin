<?php
//000000000000
 exit();?>
a:6:{s:2:"id";i:1;s:9:"role_name";s:15:"超级管理员";s:13:"role_auth_ids";s:0:"";s:12:"role_auth_ac";s:0:"";s:8:"sendtime";i:1513227497;s:6:"status";i:1;}