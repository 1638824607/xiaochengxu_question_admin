<?php
//000000000000
 exit();?>
a:9:{s:2:"id";s:1:"2";s:10:"model_name";s:17:"[单]单一内容";s:12:"model_fields";s:3:"1,9";s:7:"model_c";s:4:"News";s:7:"model_a";s:6:"Single";s:8:"disorder";s:1:"0";s:6:"status";s:1:"1";s:6:"dosave";s:0:"";s:5:"ispic";i:0;}