<?php
//000000000000
 exit();?>
a:8:{s:2:"id";i:15;s:10:"model_name";s:32:"[单]标题+摘要+详情+图片";s:12:"model_fields";s:8:"1,6,9,10";s:7:"model_c";s:4:"News";s:7:"model_a";s:6:"Single";s:5:"ispic";i:1;s:8:"disorder";i:0;s:6:"status";i:1;}