<?php
//000000000000
 exit();?>
a:8:{s:2:"id";i:16;s:10:"model_name";s:17:"[列表]广告位";s:12:"model_fields";s:6:"1,6,10";s:7:"model_c";s:4:"News";s:7:"model_a";s:5:"Index";s:5:"ispic";i:1;s:8:"disorder";i:0;s:6:"status";i:1;}