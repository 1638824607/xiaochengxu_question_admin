<?php
//000000000000
 exit();?>
a:8:{s:2:"id";i:1;s:7:"role_id";s:1:"1";s:8:"username";s:7:"jxadmin";s:8:"password";s:32:"41a11f74a6b20dac5d6cff0342d22fc7";s:8:"realname";s:7:"jxadmin";s:9:"login_num";i:139;s:6:"status";i:1;s:8:"sendtime";s:10:"1590719118";}